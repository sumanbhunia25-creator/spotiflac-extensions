# SpotiFLAC Extensions

A collection of community extensions for [SpotiFLAC Mobile](https://spotiflac.zarz.moe) — the high-quality audio downloader for Android.

## Available Extensions

| Extension | Type | Description |
|---|---|---|
| [odesli-enricher](./odesli-enricher) | Track Enrichment | Enriches tracks with ISRC + Tidal/Qobuz/Deezer IDs via Odesli (song.link) |
| [open-lyrics](./open-lyrics) | Lyrics Provider | Fetches synced LRC lyrics from LRCLIB (public, no API key needed) |
| [free-music-search](./free-music-search) | Metadata Provider | Search tracks via the Deezer public API |
| [soundcloud-provider](./soundcloud-provider) | Metadata + Download | Search and download from SoundCloud |

---

## Getting Started

### Installing an Extension

1. Download the `.spotiflac-ext` file from the [Releases](../../releases) page.
2. Open **SpotiFLAC** → **Settings** → **Extensions**.
3. Tap **+** / **Import** and select the `.spotiflac-ext` file.

### Building from Source

Each extension lives in its own folder. Requirements: **Node.js 18+**, **npm**.

```bash
cd odesli-enricher   # or any other extension
npm install
npm run build        # bundles src/index.js → dist/index.js
npm run package      # creates the .spotiflac-ext ZIP
```

The packaged file appears at `dist/<extension-name>.spotiflac-ext`.

---

## Extension Development

SpotiFLAC extensions are JavaScript files bundled into a `.spotiflac-ext` ZIP.  
Full API reference: **https://spotiflac.zarz.moe/docs**

### Quick structure

```
my-extension.spotiflac-ext (ZIP)
├── manifest.json   # metadata, permissions, settings
├── index.js        # bundled JavaScript (no require/import at runtime)
└── icon.png        # optional 128×128 PNG
```

### Key rules

- **Always call `registerExtension({...})`** at the end of your script.
- Declare every domain you call in `permissions.network`.
- Use `storage` / `credentials` APIs — no `localStorage`.
- Bundle with esbuild/rollup when splitting code across files.

---

## Contributing

1. Fork this repo.
2. Create your extension in a new folder following the structure above.
3. Add it to the table in this README.
4. Open a pull request.

Please include a working `package.json` with `build` and `package` scripts so CI can verify it.

---

## License

MIT — see [LICENSE](./LICENSE).
