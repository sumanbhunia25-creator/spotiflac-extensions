# Open Lyrics (LRCLIB)

**Type:** Lyrics Provider  
**API:** [LRCLIB](https://lrclib.net) — free, open-source, no API key required

## What it does

Fetches **synced (LRC / karaoke-style) and plain text lyrics** from LRCLIB, a community-maintained lyrics database. This extension is tried **before** SpotiFLAC's built-in providers (Musixmatch, Netease, etc.).

### Lookup strategy

1. **`/get`** endpoint — exact match by track name + artist + album + duration  
2. **`/search`** fallback — fuzzy match, best duration match within tolerance

Results are cached locally so repeat plays don't hit the API.

## Settings

| Setting | Default | Description |
|---|---|---|
| Prefer Synced Lyrics | `true` | Use `LINE_SYNCED` when available |
| Duration Tolerance | `5` sec | Acceptable duration mismatch for search fallback |
| Cache Lyrics | `true` | Cache to `storage` API to reduce API calls |

## Build & install

```bash
npm install
npm run build
npm run package   # → dist/open-lyrics.spotiflac-ext
```

## LRC format parsing

The extension fully parses standard `[mm:ss.xx]` LRC timestamps into SpotiFLAC's `lines[]` format, including end-time calculation from the next line's start time.

## License

MIT
