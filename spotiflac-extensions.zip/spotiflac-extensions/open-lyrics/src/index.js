// ============================================================
// Open Lyrics (LRCLIB) — SpotiFLAC Lyrics Provider Extension
// ============================================================
// LRCLIB is a free, open crowd-sourced lyrics database.
// API docs: https://lrclib.net/docs
// No API key required.
// ============================================================

var settings = {};

// ---------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------

function initialize(config) {
  settings = config || {};
  if (settings.durationToleranceSec === undefined) {
    settings.durationToleranceSec = 5;
  }
  log.info("[open-lyrics] initialized");
  return true;
}

function cleanup() {
  log.info("[open-lyrics] cleanup");
}

// ---------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------

var LRCLIB_BASE = "https://lrclib.net/api";

/**
 * Build a stable cache key for a lyrics lookup.
 */
function buildCacheKey(trackName, artistName, durationSec) {
  var raw = [
    trackName.toLowerCase().trim(),
    artistName.toLowerCase().trim(),
    Math.round(durationSec)
  ].join("|");
  return "lrclib_" + utils.md5(raw);
}

/**
 * Call LRCLIB /get endpoint (exact match by track+artist+duration).
 * Returns parsed JSON or null.
 */
function lrclibGet(trackName, artistName, albumName, durationSec) {
  var params = [
    "track_name=" + encodeURIComponent(trackName),
    "artist_name=" + encodeURIComponent(artistName)
  ];
  if (albumName) params.push("album_name=" + encodeURIComponent(albumName));
  if (durationSec && durationSec > 0) params.push("duration=" + Math.round(durationSec));

  var url = LRCLIB_BASE + "/get?" + params.join("&");

  try {
    var resp = fetch(url, { method: "GET" });
    if (!resp || resp.status === 404) return null;
    if (!resp.ok) {
      log.warn("[open-lyrics] /get returned status " + resp.status);
      return null;
    }
    return resp.json();
  } catch (e) {
    log.error("[open-lyrics] /get fetch error:", String(e));
    return null;
  }
}

/**
 * Call LRCLIB /search endpoint as fallback.
 * Returns the best match within duration tolerance.
 */
function lrclibSearch(trackName, artistName, durationSec) {
  var toleranceSec = settings.durationToleranceSec || 5;
  var params = [
    "track_name=" + encodeURIComponent(trackName),
    "artist_name=" + encodeURIComponent(artistName)
  ];

  var url = LRCLIB_BASE + "/search?" + params.join("&");

  try {
    var resp = fetch(url, { method: "GET" });
    if (!resp || !resp.ok) return null;
    var results = resp.json();
    if (!results || !Array.isArray(results) || results.length === 0) return null;

    // If duration unknown, return first result
    if (!durationSec || durationSec <= 0) return results[0];

    // Find best duration match
    var best = null;
    var bestDiff = Infinity;

    for (var i = 0; i < results.length; i++) {
      var r = results[i];
      if (!r.duration) continue;
      var diff = Math.abs(r.duration - durationSec);
      if (diff < bestDiff && diff <= toleranceSec) {
        best = r;
        bestDiff = diff;
      }
    }

    return best || results[0];
  } catch (e) {
    log.error("[open-lyrics] /search fetch error:", String(e));
    return null;
  }
}

/**
 * Parse an LRC-format string into an array of line objects.
 * Handles [mm:ss.xx] and [mm:ss] timestamps.
 *
 * @param {string} lrc
 * @returns {Array<{startTimeMs: number, words: string, endTimeMs: number}>}
 */
function parseLRC(lrc) {
  if (!lrc || lrc.trim() === "") return [];

  var lines = lrc.split("\n");
  var parsed = [];
  var timePattern = /^\[(\d+):(\d+(?:\.\d+)?)\](.*)$/;

  for (var i = 0; i < lines.length; i++) {
    var line = lines[i].trim();
    var match = line.match(timePattern);
    if (!match) continue;

    var minutes = parseInt(match[1], 10);
    var seconds = parseFloat(match[2]);
    var text = match[3].trim();

    var startMs = Math.round((minutes * 60 + seconds) * 1000);

    // Skip metadata tags like [ar:...], [ti:...], [length:...]
    if (/^[a-z]{2}:/.test(text)) continue;

    parsed.push({
      startTimeMs: startMs,
      words: text,
      endTimeMs: 0  // filled in next pass
    });
  }

  // Fill endTimeMs from next line's start
  for (var j = 0; j < parsed.length - 1; j++) {
    parsed[j].endTimeMs = parsed[j + 1].startTimeMs;
  }
  if (parsed.length > 0) {
    parsed[parsed.length - 1].endTimeMs = parsed[parsed.length - 1].startTimeMs + 5000;
  }

  return parsed;
}

/**
 * Build the SpotiFLAC lyrics result from an LRCLIB response object.
 */
function buildResult(data) {
  if (!data) return null;

  // Instrumental
  if (data.instrumental === true) {
    return {
      lines: [],
      syncType: "LINE_SYNCED",
      instrumental: true,
      plainLyrics: "",
      provider: "LRCLIB"
    };
  }

  var preferSynced = settings.preferSynced !== false;

  // Synced lyrics
  if (preferSynced && data.syncedLyrics) {
    var lines = parseLRC(data.syncedLyrics);
    if (lines.length > 0) {
      return {
        lines: lines,
        syncType: "LINE_SYNCED",
        instrumental: false,
        plainLyrics: data.plainLyrics || "",
        provider: "LRCLIB"
      };
    }
  }

  // Plain lyrics fallback
  if (data.plainLyrics && data.plainLyrics.trim() !== "") {
    return {
      lines: [],
      syncType: "UNSYNCED",
      instrumental: false,
      plainLyrics: data.plainLyrics,
      provider: "LRCLIB"
    };
  }

  return null;
}

// ---------------------------------------------------------------
// fetchLyrics — main lyrics hook
// ---------------------------------------------------------------

/**
 * Fetch lyrics for a track.
 * Called by SpotiFLAC before the built-in lyrics providers.
 *
 * @param {string} trackName
 * @param {string} artistName
 * @param {string} albumName   May be empty string.
 * @param {number} durationSec Track duration in seconds.
 * @returns {Object|null} Lyrics result, or null to try next provider.
 */
function fetchLyrics(trackName, artistName, albumName, durationSec) {
  if (!trackName || !artistName) return null;

  var key = buildCacheKey(trackName, artistName, durationSec);

  // Cache hit
  if (settings.cacheResults !== false) {
    try {
      var cached = storage.get(key);
      if (cached) {
        log.debug("[open-lyrics] cache hit:", trackName, "-", artistName);
        var parsed = JSON.parse(cached);
        return parsed === null ? null : parsed;
      }
    } catch (e) {
      // Cache miss or parse error — proceed normally
    }
  }

  // 1. Try exact match
  var data = lrclibGet(trackName, artistName, albumName, durationSec);

  // 2. Fallback: search
  if (!data) {
    log.debug("[open-lyrics] /get miss, falling back to /search");
    data = lrclibSearch(trackName, artistName, durationSec);
  }

  var result = buildResult(data);

  // Store in cache (including null so we don't retry failed lookups)
  if (settings.cacheResults !== false) {
    try {
      storage.set(key, JSON.stringify(result));
    } catch (e) {
      // Ignore cache write failures
    }
  }

  if (result) {
    log.info("[open-lyrics] found lyrics (" + result.syncType + ") for:", trackName, "-", artistName);
  } else {
    log.debug("[open-lyrics] no lyrics found for:", trackName, "-", artistName);
  }

  return result;
}

// ---------------------------------------------------------------
// Register
// ---------------------------------------------------------------

registerExtension({
  initialize: initialize,
  cleanup: cleanup,
  fetchLyrics: fetchLyrics
});

log.info("[open-lyrics] loaded");
