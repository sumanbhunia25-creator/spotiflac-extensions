# Odesli Track Enricher

**Type:** Metadata Provider (Track Enrichment Hook)  
**API:** [Odesli / song.link](https://odesli.co) — free, no key required

## What it does

This extension hooks into SpotiFLAC's **pre-download enrichment** step. Just before a track is downloaded it calls the Odesli API to:

1. **Resolve a real ISRC** from any streaming URL (YouTube Music, SoundCloud, etc.)
2. **Extract Tidal, Qobuz, and Deezer track IDs** so SpotiFLAC can download lossless audio *directly* — no extra search round-trip needed

### Download priority after enrichment

```
Your source extension (YouTube Music, SoundCloud…)
        │
        ▼
  enrichTrack() called [this extension]
        │
        ▼
  Odesli → tidal_id  → Direct Tidal FLAC/MQA download  ← highest priority
         → qobuz_id → Direct Qobuz Hi-Res FLAC
         → isrc     → Tidal/Qobuz ISRC search fallback
         → deezer_id → Deezer FLAC fallback
```

## Settings

| Setting | Default | Description |
|---|---|---|
| Preferred Lossless Service | `tidal` | `tidal`, `qobuz`, or `deezer` — which ID to prioritize |
| Cache Odesli Results | `true` | Avoid repeat API calls for the same track |
| Debug Logging | `false` | Verbose logs for troubleshooting |

## Build & install

```bash
npm install
npm run build    # → dist/index.js
npm run package  # → dist/odesli-enricher.spotiflac-ext
```

Then import `dist/odesli-enricher.spotiflac-ext` in SpotiFLAC → Settings → Extensions.

## Notes

- This extension does **not** provide its own search UI — it only enriches tracks found by other extensions.
- Results are cached locally (`storage` API) to respect Odesli's rate limits.
- The Odesli API is free and does not require an API key for personal use.
