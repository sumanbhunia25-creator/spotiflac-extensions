// ============================================================
// Odesli Track Enricher — SpotiFLAC Extension
// ============================================================
// Uses the Odesli / song.link API to:
//   1. Resolve a real ISRC from any streaming service URL
//   2. Extract Tidal, Qobuz, and Deezer track IDs
//      so SpotiFLAC can download lossless audio directly
//      (without an extra search round-trip).
//
// This extension acts purely as a metadata enrichment hook.
// It does NOT provide search or download by itself.
// ============================================================

var settings = {};

// ---------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------

function initialize(config) {
  settings = config || {};
  log.info("[odesli-enricher] initialized, preferredService=" + (settings.preferredService || "tidal"));
  return true;
}

function cleanup() {
  log.info("[odesli-enricher] cleanup");
}

// ---------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------

var ODESLI_BASE = "https://api.song.link/v1-alpha.1/links";

/**
 * Build the Odesli lookup URL.
 * @param {string} sourceUrl  Any supported streaming URL.
 * @returns {string}
 */
function buildOdesliUrl(sourceUrl) {
  return ODESLI_BASE + "?url=" + encodeURIComponent(sourceUrl) + "&songIfSingle=true";
}

/**
 * Cache key for a given source URL.
 * @param {string} sourceUrl
 * @returns {string}
 */
function cacheKey(sourceUrl) {
  return "odesli_cache_" + utils.md5(sourceUrl);
}

/**
 * Fetch Odesli data for a URL, with optional local caching.
 * @param {string} sourceUrl
 * @returns {Object|null} Parsed Odesli JSON or null on failure.
 */
function fetchOdesli(sourceUrl) {
  var key = cacheKey(sourceUrl);

  // Return cached result when enabled
  if (settings.cacheResults !== false) {
    var cached = storage.get(key);
    if (cached) {
      if (settings.debugLogs) log.debug("[odesli-enricher] cache hit for", sourceUrl);
      return JSON.parse(cached);
    }
  }

  var url = buildOdesliUrl(sourceUrl);
  if (settings.debugLogs) log.debug("[odesli-enricher] GET", url);

  try {
    var resp = fetch(url, {
      method: "GET",
      headers: {
        "User-Agent": "SpotiFLAC-Extension/1.0 (odesli-enricher)"
      }
    });

    if (!resp || !resp.ok) {
      log.warn("[odesli-enricher] Odesli request failed, status=" + (resp ? resp.status : "none"));
      return null;
    }

    var data = resp.json();
    if (!data) return null;

    // Cache the raw result
    if (settings.cacheResults !== false) {
      storage.set(key, JSON.stringify(data));
    }

    return data;
  } catch (e) {
    log.error("[odesli-enricher] fetch error:", String(e));
    return null;
  }
}

/**
 * Extract the first ISRC found in an Odesli response.
 * @param {Object} data  Odesli response JSON.
 * @returns {string|null}
 */
function extractISRC(data) {
  if (!data || !data.entitiesByUniqueId) return null;
  var keys = Object.keys(data.entitiesByUniqueId);
  for (var i = 0; i < keys.length; i++) {
    var entity = data.entitiesByUniqueId[keys[i]];
    if (entity && entity.isrc) return entity.isrc;
  }
  return null;
}

/**
 * Extract platform-specific track IDs from an Odesli response.
 * @param {Object} data  Odesli response JSON.
 * @returns {Object} Map of platform → { url, id }
 */
function extractPlatformIds(data) {
  var out = {};
  if (!data || !data.linksByPlatform) return out;

  var platforms = {
    tidal:   /\/track\/(\d+)/,
    qobuz:   /\/track\/(\d+)/,
    deezer:  /\/track\/(\d+)/,
    spotify: /\/track\/([a-zA-Z0-9]+)/,
    appleMusic: /\/([0-9]+)(?:\?|$)/
  };

  var links = data.linksByPlatform;
  var platformKeys = Object.keys(platforms);

  for (var i = 0; i < platformKeys.length; i++) {
    var platform = platformKeys[i];
    if (links[platform] && links[platform].url) {
      var platformUrl = links[platform].url;
      var match = platformUrl.match(platforms[platform]);
      out[platform] = {
        url: platformUrl,
        id: match ? match[1] : null
      };
    }
  }

  return out;
}

/**
 * Build a canonical streaming URL from a track object's known provider.
 * Returns null if the track doesn't have enough info for Odesli lookup.
 *
 * @param {Object} track
 * @returns {string|null}
 */
function buildSourceUrl(track) {
  // If the track already carries a Spotify ID
  if (track.spotify_id) {
    return "https://open.spotify.com/track/" + track.spotify_id;
  }
  // YouTube Music ID (11-char video ID)
  if (track.id && /^[a-zA-Z0-9_-]{11}$/.test(track.id)) {
    return "https://music.youtube.com/watch?v=" + track.id;
  }
  // Deezer ID (numeric)
  if (track.deezer_id) {
    return "https://www.deezer.com/track/" + track.deezer_id;
  }
  // SoundCloud permalink
  if (track.permalink_url && track.permalink_url.indexOf("soundcloud.com") !== -1) {
    return track.permalink_url;
  }
  return null;
}

// ---------------------------------------------------------------
// enrichTrack — main hook called by SpotiFLAC before download
// ---------------------------------------------------------------

/**
 * Enrich a track object with ISRC + platform IDs from Odesli.
 *
 * SpotiFLAC calls this function just before initiating a download.
 * We add:
 *   - track.isrc          → enables built-in Tidal/Qobuz search fallback
 *   - track.tidal_id      → enables direct Tidal download (no search!)
 *   - track.qobuz_id      → enables direct Qobuz download (no search!)
 *   - track.deezer_id     → enables Deezer fallback
 *   - track.external_links → full URL map for reference
 *
 * @param {Object} track
 * @returns {Object} Enriched track (or original if enrichment not possible)
 */
function enrichTrack(track) {
  if (!track || !track.id) return track;

  // Build source URL for Odesli lookup
  var sourceUrl = buildSourceUrl(track);
  if (!sourceUrl) {
    if (settings.debugLogs) log.debug("[odesli-enricher] no source URL for track:", track.id);
    return track;
  }

  if (settings.debugLogs) log.debug("[odesli-enricher] enriching track:", track.name, "via", sourceUrl);

  var data = fetchOdesli(sourceUrl);
  if (!data) return track;

  var enrichment = {};

  // ISRC
  var isrc = extractISRC(data);
  if (isrc && !track.isrc) {
    enrichment.isrc = isrc;
    if (settings.debugLogs) log.debug("[odesli-enricher] ISRC:", isrc);
  }

  // Platform IDs
  var ids = extractPlatformIds(data);
  enrichment.external_links = {};

  var preferred = settings.preferredService || "tidal";

  // Always attach what we have
  if (ids.tidal) {
    enrichment.external_links.tidal = ids.tidal.url;
    if (ids.tidal.id) {
      enrichment.tidal_id = ids.tidal.id;
      if (settings.debugLogs) log.debug("[odesli-enricher] tidal_id:", ids.tidal.id);
    }
  }
  if (ids.qobuz) {
    enrichment.external_links.qobuz = ids.qobuz.url;
    if (ids.qobuz.id) {
      enrichment.qobuz_id = ids.qobuz.id;
      if (settings.debugLogs) log.debug("[odesli-enricher] qobuz_id:", ids.qobuz.id);
    }
  }
  if (ids.deezer) {
    enrichment.external_links.deezer = ids.deezer.url;
    if (ids.deezer.id && !track.deezer_id) {
      enrichment.deezer_id = ids.deezer.id;
    }
  }
  if (ids.spotify) {
    enrichment.external_links.spotify = ids.spotify.url;
    if (ids.spotify.id && !track.spotify_id) {
      enrichment.spotify_id = ids.spotify.id;
    }
  }
  if (ids.appleMusic) {
    enrichment.external_links.apple = ids.appleMusic.url;
  }

  // Log download path chosen
  if (preferred === "qobuz" && enrichment.qobuz_id) {
    log.info("[odesli-enricher] will use Qobuz direct download for:", track.name);
  } else if (enrichment.tidal_id) {
    log.info("[odesli-enricher] will use Tidal direct download for:", track.name);
  } else if (enrichment.isrc || track.isrc) {
    log.info("[odesli-enricher] will search by ISRC:", enrichment.isrc || track.isrc);
  }

  return Object.assign({}, track, enrichment);
}

// ---------------------------------------------------------------
// searchTracks — minimal stub (required for metadata_provider)
// ---------------------------------------------------------------
// This extension doesn't provide its own search.
// Return an empty array so SpotiFLAC falls through to other providers.

function searchTracks(query, limit) {
  return [];
}

// ---------------------------------------------------------------
// Register
// ---------------------------------------------------------------

registerExtension({
  initialize: initialize,
  cleanup: cleanup,
  searchTracks: searchTracks,
  enrichTrack: enrichTrack
});

log.info("[odesli-enricher] loaded");
