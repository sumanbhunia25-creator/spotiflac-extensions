// ============================================================
// Deezer Search — SpotiFLAC Metadata Provider Extension
// ============================================================
// Uses the public Deezer API (no authentication required).
// Provides: track search, album browsing, artist pages,
//           and playlist support.
//
// Pairs with "Odesli Enricher" to enable Tidal/Qobuz
// lossless downloads for found tracks.
// ============================================================

var settings = {};

// ---------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------

function initialize(config) {
  settings = config || {};
  log.info("[deezer-search] initialized");
  return true;
}

function cleanup() {
  log.info("[deezer-search] cleanup");
}

// ---------------------------------------------------------------
// Deezer API helpers
// ---------------------------------------------------------------

var DEEZER_API = "https://api.deezer.com";

/**
 * GET a Deezer API endpoint. Returns parsed JSON or null.
 * @param {string} path  e.g. "/search?q=..."
 */
function deezerGet(path) {
  try {
    var resp = fetch(DEEZER_API + path, { method: "GET" });
    if (!resp || !resp.ok) {
      log.warn("[deezer-search] request failed:", path, "status=" + (resp ? resp.status : "none"));
      return null;
    }
    var data = resp.json();
    // Deezer wraps errors in { error: { ... } }
    if (data && data.error) {
      log.warn("[deezer-search] API error:", JSON.stringify(data.error));
      return null;
    }
    return data;
  } catch (e) {
    log.error("[deezer-search] fetch error:", String(e));
    return null;
  }
}

/**
 * Convert a Deezer track object to SpotiFLAC track format.
 */
function formatTrack(t, albumOverride) {
  var album = albumOverride || t.album || {};
  return {
    id: String(t.id),
    name: t.title,
    artists: t.artist ? t.artist.name : (t.contributors ? t.contributors.map(function(c) { return c.name; }).join(", ") : "Unknown"),
    album_name: album.title || "",
    album_artist: t.artist ? t.artist.name : "",
    isrc: t.isrc || "",
    duration_ms: (t.duration || 0) * 1000,
    track_number: t.track_position || 1,
    disc_number: t.disk_number || 1,
    release_date: album.release_date || "",
    images: album.cover_xl || album.cover_big || album.cover || "",
    deezer_id: String(t.id),
    explicit: t.explicit_lyrics || false
  };
}

/**
 * Convert a Deezer album object to the summary format used in search results.
 */
function formatAlbumItem(a) {
  return {
    id: String(a.id),
    name: a.title,
    artists: a.artist ? a.artist.name : "",
    album_name: a.title,
    release_date: a.release_date || "",
    cover_url: a.cover_xl || a.cover_big || a.cover || "",
    album_type: a.record_type || "album",
    total_tracks: a.nb_tracks || 0,
    item_type: "album",
    deezer_id: String(a.id)
  };
}

/**
 * Convert a Deezer artist object to search result format.
 */
function formatArtistItem(a) {
  return {
    id: String(a.id),
    name: a.name,
    artists: a.name,
    cover_url: a.picture_xl || a.picture_big || a.picture || "",
    item_type: "artist",
    deezer_id: String(a.id)
  };
}

/**
 * Convert a Deezer playlist object to search result format.
 */
function formatPlaylistItem(p) {
  return {
    id: String(p.id),
    name: p.title,
    artists: p.creator ? p.creator.name : "",
    album_name: p.title,
    cover_url: p.picture_xl || p.picture_big || p.picture || "",
    album_type: "playlist",
    total_tracks: p.nb_tracks || 0,
    item_type: "playlist",
    deezer_id: String(p.id)
  };
}

// ---------------------------------------------------------------
// searchTracks — standard metadata provider search
// ---------------------------------------------------------------

function searchTracks(query, limit) {
  var maxLimit = Math.min(Math.max(1, parseInt(settings.searchLimit || limit || 25, 10)), 50);
  var data = deezerGet("/search?q=" + encodeURIComponent(query) + "&limit=" + maxLimit + "&output=json");
  if (!data || !data.data) return [];

  var tracks = data.data;
  var out = [];

  for (var i = 0; i < tracks.length; i++) {
    var t = tracks[i];
    if (!settings.explicitContent && t.explicit_lyrics) continue;
    out.push(formatTrack(t));
  }

  return out;
}

// ---------------------------------------------------------------
// customSearch — mixed results (tracks + albums + artists)
// ---------------------------------------------------------------

function customSearch(query, options) {
  var limit = parseInt(settings.searchLimit || 25, 10);
  var searchTypes = settings.searchTypes || "tracks+albums";
  var wantAlbums = searchTypes.indexOf("albums") !== -1;
  var wantArtists = searchTypes.indexOf("artists") !== -1;
  var includeExplicit = settings.explicitContent !== false;

  var out = [];

  // Tracks
  var trackData = deezerGet("/search?q=" + encodeURIComponent(query) + "&limit=" + limit);
  if (trackData && trackData.data) {
    for (var i = 0; i < trackData.data.length; i++) {
      var t = trackData.data[i];
      if (!includeExplicit && t.explicit_lyrics) continue;
      out.push(formatTrack(t));
    }
  }

  // Albums
  if (wantAlbums) {
    var albumData = deezerGet("/search/album?q=" + encodeURIComponent(query) + "&limit=10");
    if (albumData && albumData.data) {
      for (var j = 0; j < albumData.data.length; j++) {
        out.push(formatAlbumItem(albumData.data[j]));
      }
    }
  }

  // Artists
  if (wantArtists) {
    var artistData = deezerGet("/search/artist?q=" + encodeURIComponent(query) + "&limit=5");
    if (artistData && artistData.data) {
      for (var k = 0; k < artistData.data.length; k++) {
        out.push(formatArtistItem(artistData.data[k]));
      }
    }
  }

  return out;
}

// ---------------------------------------------------------------
// getTrack
// ---------------------------------------------------------------

function getTrack(trackId) {
  var data = deezerGet("/track/" + trackId);
  if (!data) return null;
  return formatTrack(data);
}

// ---------------------------------------------------------------
// getAlbum
// ---------------------------------------------------------------

function getAlbum(albumId) {
  var data = deezerGet("/album/" + albumId);
  if (!data) return null;

  var tracks = [];
  if (data.tracks && data.tracks.data) {
    for (var i = 0; i < data.tracks.data.length; i++) {
      tracks.push(formatTrack(data.tracks.data[i], data));
    }
  }

  return {
    id: String(data.id),
    name: data.title,
    artists: data.artist ? data.artist.name : "",
    cover_url: data.cover_xl || data.cover_big || data.cover || "",
    release_date: data.release_date || "",
    total_tracks: data.nb_tracks || tracks.length,
    album_type: data.record_type || "album",
    tracks: tracks,
    provider_id: "free-music-search"
  };
}

// ---------------------------------------------------------------
// getPlaylist
// ---------------------------------------------------------------

function getPlaylist(playlistId) {
  var data = deezerGet("/playlist/" + playlistId);
  if (!data) return null;

  var tracks = [];
  if (data.tracks && data.tracks.data) {
    for (var i = 0; i < data.tracks.data.length; i++) {
      var t = data.tracks.data[i];
      if (!settings.explicitContent && t.explicit_lyrics) continue;
      tracks.push(formatTrack(t));
    }
  }

  return {
    id: String(data.id),
    name: data.title,
    owner: data.creator ? data.creator.name : "",
    cover_url: data.picture_xl || data.picture_big || data.picture || "",
    total_tracks: tracks.length,
    tracks: tracks,
    provider_id: "free-music-search"
  };
}

// ---------------------------------------------------------------
// getArtist
// ---------------------------------------------------------------

function getArtist(artistId) {
  var info = deezerGet("/artist/" + artistId);
  if (!info) return null;

  var albumData = deezerGet("/artist/" + artistId + "/albums?limit=50");
  var albums = [];

  if (albumData && albumData.data) {
    for (var i = 0; i < albumData.data.length; i++) {
      var a = albumData.data[i];
      albums.push({
        id: String(a.id),
        name: a.title,
        artists: info.name,
        cover_url: a.cover_xl || a.cover_big || a.cover || "",
        release_date: a.release_date || "",
        total_tracks: a.nb_tracks || 0,
        album_type: a.record_type || "album",
        provider_id: "free-music-search"
      });
    }
  }

  return {
    id: String(info.id),
    name: info.name,
    image_url: info.picture_xl || info.picture_big || info.picture || "",
    albums: albums,
    provider_id: "free-music-search"
  };
}

// ---------------------------------------------------------------
// Register
// ---------------------------------------------------------------

registerExtension({
  initialize: initialize,
  cleanup: cleanup,

  // Standard metadata provider
  searchTracks: searchTracks,
  getTrack: getTrack,
  getAlbum: getAlbum,
  getArtist: getArtist,
  getPlaylist: getPlaylist,

  // Custom search UI (mixed results)
  customSearch: customSearch
});

log.info("[deezer-search] loaded");
