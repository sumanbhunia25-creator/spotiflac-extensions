# Deezer Search

**Type:** Metadata Provider  
**API:** [Deezer Public API](https://developers.deezer.com/api) — no account or API key required

## What it does

Adds a **"Deezer Search"** tab to SpotiFLAC with:

- **Mixed search results** — tracks, albums, and artists in one query
- **Album browsing** — tap an album to see its full track list
- **Artist pages** — discography with all albums
- **Playlist support** — browse and download public Deezer playlists
- **ISRC passthrough** — Deezer ISRCs flow straight into SpotiFLAC's download pipeline

### Recommended combo

Install alongside **Odesli Enricher** for automatic Tidal/Qobuz lossless download resolution from any Deezer search result.

## Settings

| Setting | Default | Description |
|---|---|---|
| Search Result Types | `tracks+albums` | Which types appear in the custom search tab |
| Results per Search | `25` | 1–50 |
| Include Explicit Content | `true` | Filter out explicit tracks when disabled |

## Build & install

```bash
npm install
npm run build
npm run package   # → dist/free-music-search.spotiflac-ext
```

## API notes

The Deezer public API has a rate limit of ~50 requests/5 seconds per IP. The extension does not implement additional caching beyond what SpotiFLAC provides — add `storage` caching if you hit limits.

## License

MIT
