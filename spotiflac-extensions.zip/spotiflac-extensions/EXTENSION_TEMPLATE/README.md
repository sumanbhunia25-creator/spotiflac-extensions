# My Extension

**Type:** Metadata Provider / Download Provider / Lyrics Provider  
**API:** Your API here

## What it does

Describe your extension in 1–2 sentences.

## Settings

| Setting | Default | Description |
|---|---|---|
| API Key | *(required)* | Your API key |

## Build & install

```bash
# 1. Rename this folder to your extension name
# 2. Update manifest.json fields (name, displayName, permissions…)
# 3. Implement functions in src/index.js
# 4. Build and package:
npm install
npm run build
npm run package   # → dist/my-extension.spotiflac-ext
```

## API reference

Full SpotiFLAC extension API: https://spotiflac.zarz.moe/docs

## License

MIT
