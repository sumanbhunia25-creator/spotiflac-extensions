// ============================================================
// My Extension — SpotiFLAC Extension Template
// ============================================================
// Docs: https://spotiflac.zarz.moe/docs
// ============================================================

var settings = {};

// ---------------------------------------------------------------
// LIFECYCLE (Required)
// ---------------------------------------------------------------

/**
 * Called when the extension is loaded.
 * @param {Object} config  User settings from manifest.json
 * @returns {boolean} true on success, throw to signal error
 */
function initialize(config) {
  settings = config || {};
  log.info("[my-extension] initialized");

  // Validate required settings
  if (!settings.apiKey) {
    throw new Error("API Key is required. Please configure it in Settings → Extensions.");
  }

  return true;
}

/**
 * Called when the extension is unloaded.
 */
function cleanup() {
  log.info("[my-extension] cleanup");
}

// ---------------------------------------------------------------
// METADATA PROVIDER (if type includes "metadata_provider")
// ---------------------------------------------------------------

/**
 * Search tracks by query string.
 * @param {string} query
 * @param {number} limit  Max results requested
 * @returns {Array} Array of SpotiFLAC track objects
 */
function searchTracks(query, limit) {
  var resp = fetch("https://api.example.com/search?q=" + encodeURIComponent(query) + "&limit=" + limit, {
    method: "GET",
    headers: {
      "Authorization": "Bearer " + settings.apiKey
    }
  });

  if (!resp || !resp.ok) return [];

  var data = resp.json();
  if (!data || !data.tracks) return [];

  return data.tracks.map(function(t) {
    return {
      id: String(t.id),
      name: t.title,
      artists: t.artist,
      album_name: t.album || "",
      isrc: t.isrc || "",
      duration_ms: (t.duration || 0) * 1000,
      track_number: t.trackNumber || 1,
      disc_number: t.discNumber || 1,
      release_date: t.releaseDate || "",
      images: t.coverUrl || ""
    };
  });
}

// ---------------------------------------------------------------
// DOWNLOAD PROVIDER (if type includes "download_provider")
// ---------------------------------------------------------------

/**
 * Check if a track is available for download.
 * @param {string} isrc
 * @param {string} trackName
 * @param {string} artistName
 * @returns {{ available: boolean, track_id?: string, quality?: string }}
 */
function checkAvailability(isrc, trackName, artistName) {
  // TODO: implement
  return { available: false };
}

/**
 * Get the stream/download URL for a track.
 * @param {string} trackId
 * @param {string} quality
 * @returns {{ success: boolean, url?: string, format?: string }}
 */
function getDownloadUrl(trackId, quality) {
  // TODO: implement
  return { success: false, error: "Not implemented" };
}

/**
 * Download a track to disk.
 * @param {Object} request          Download request from SpotiFLAC
 * @param {Function} progressCallback  Called with (percent 0–1)
 * @returns {{ success: boolean, file_path?: string, format?: string }}
 */
function download(request, progressCallback) {
  var avail = checkAvailability(request.isrc, request.track_name, request.artist_name);
  if (!avail.available) {
    return { success: false, error: "Track not found", error_type: "not_found" };
  }

  var dlInfo = getDownloadUrl(avail.track_id, request.quality);
  if (!dlInfo.success) {
    return { success: false, error: dlInfo.error, error_type: "stream_error" };
  }

  var filename = gobackend.sanitizeFilename(request.track_name + " - " + request.artist_name) + ".mp3";
  var outputPath = request.output_dir + "/" + filename;

  var result = file.download(dlInfo.url, outputPath, {
    onProgress: function(received, total) {
      progressCallback(total > 0 ? received / total : 0);
    }
  });

  if (!result.success) {
    return { success: false, error: result.error, error_type: "download_error" };
  }

  return { success: true, file_path: outputPath, format: "mp3" };
}

// ---------------------------------------------------------------
// LYRICS PROVIDER (if type includes "lyrics_provider")
// ---------------------------------------------------------------

/**
 * Fetch lyrics for a track.
 * @param {string} trackName
 * @param {string} artistName
 * @param {string} albumName
 * @param {number} durationSec
 * @returns {Object|null} Lyrics result, or null to try next provider
 */
function fetchLyrics(trackName, artistName, albumName, durationSec) {
  // TODO: implement
  return null;
}

// ---------------------------------------------------------------
// REGISTER (REQUIRED — must be last statement)
// ---------------------------------------------------------------

registerExtension({
  // Lifecycle
  initialize: initialize,
  cleanup: cleanup,

  // Uncomment what your extension implements:
  searchTracks: searchTracks,
  // checkAvailability: checkAvailability,
  // getDownloadUrl: getDownloadUrl,
  // download: download,
  // fetchLyrics: fetchLyrics,
});

log.info("[my-extension] loaded");
