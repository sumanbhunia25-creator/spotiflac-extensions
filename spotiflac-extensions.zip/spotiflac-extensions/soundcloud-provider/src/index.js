// ============================================================
// SoundCloud Provider — SpotiFLAC Metadata + Download Extension
// ============================================================
// Provides:
//   - Track search via SoundCloud API v2
//   - Custom search tab with track results
//   - URL handler for soundcloud.com and snd.sc links
//   - HLS AAC / MP3 download
//
// IMPORTANT: SoundCloud requires a client_id for API access.
// Extract yours from https://soundcloud.com network requests:
//   Open DevTools → Network → filter "client_id=" → copy value
// ============================================================

var settings = {};
var clientId = "";

// ---------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------

function initialize(config) {
  settings = config || {};
  clientId = settings.clientId || "";

  if (!clientId) {
    log.warn("[soundcloud] No client_id configured. Search and downloads will fail.");
    // Don't throw — let the user configure it via settings
  } else {
    log.info("[soundcloud] initialized with client_id=" + clientId.substring(0, 6) + "...");
  }

  return true;
}

function cleanup() {
  log.info("[soundcloud] cleanup");
}

// ---------------------------------------------------------------
// SoundCloud API helpers
// ---------------------------------------------------------------

var SC_API = "https://api-v2.soundcloud.com";

/**
 * Append client_id to a URL.
 */
function withClientId(url) {
  var sep = url.indexOf("?") !== -1 ? "&" : "?";
  return url + sep + "client_id=" + encodeURIComponent(clientId);
}

/**
 * GET a SoundCloud API endpoint. Returns parsed JSON or null.
 */
function scGet(path) {
  if (!clientId) return null;
  try {
    var resp = fetch(withClientId(SC_API + path), {
      method: "GET",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json"
      }
    });
    if (!resp || !resp.ok) {
      log.warn("[soundcloud] request failed:", path, "status=" + (resp ? resp.status : "none"));
      return null;
    }
    return resp.json();
  } catch (e) {
    log.error("[soundcloud] fetch error:", String(e));
    return null;
  }
}

/**
 * Resolve a SoundCloud URL to a track/playlist object.
 * Uses /resolve endpoint.
 */
function scResolve(url) {
  if (!clientId) return null;
  try {
    var resolveUrl = withClientId(SC_API + "/resolve?url=" + encodeURIComponent(url));
    var resp = fetch(resolveUrl, {
      method: "GET",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json"
      }
    });
    if (!resp || !resp.ok) return null;
    return resp.json();
  } catch (e) {
    log.error("[soundcloud] resolve error:", String(e));
    return null;
  }
}

/**
 * Convert a SoundCloud track object to SpotiFLAC format.
 */
function formatTrack(t) {
  var artistName = t.user ? t.user.username : "Unknown";
  var thumbnail = t.artwork_url
    ? t.artwork_url.replace("-large", "-t500x500")
    : (t.user && t.user.avatar_url ? t.user.avatar_url.replace("-large", "-t500x500") : "");

  return {
    id: String(t.id),
    name: t.title,
    artists: artistName,
    album_name: t.publisher_metadata && t.publisher_metadata.album_title
      ? t.publisher_metadata.album_title
      : artistName,
    album_artist: artistName,
    isrc: t.publisher_metadata && t.publisher_metadata.isrc
      ? t.publisher_metadata.isrc
      : "",
    duration_ms: t.duration || 0,
    release_date: t.created_at ? t.created_at.substring(0, 10) : "",
    images: thumbnail,
    permalink_url: t.permalink_url || "",
    // Store full genre for metadata
    genre: t.genre || "",
    // SC-specific fields used by download function
    _sc_id: String(t.id),
    _sc_streamable: t.streamable !== false,
    _sc_media: t.media || null
  };
}

// ---------------------------------------------------------------
// searchTracks
// ---------------------------------------------------------------

function searchTracks(query, limit) {
  var maxLimit = Math.min(Math.max(1, parseInt(settings.searchLimit || limit || 20, 10)), 50);
  var data = scGet("/search/tracks?q=" + encodeURIComponent(query) + "&limit=" + maxLimit);
  if (!data || !data.collection) return [];

  return data.collection
    .filter(function(t) { return t.streamable !== false; })
    .map(formatTrack);
}

// ---------------------------------------------------------------
// customSearch — same as searchTracks for now
// ---------------------------------------------------------------

function customSearch(query, options) {
  return searchTracks(query, parseInt(settings.searchLimit || 20, 10));
}

// ---------------------------------------------------------------
// getTrack
// ---------------------------------------------------------------

function getTrack(trackId) {
  var data = scGet("/tracks/" + trackId);
  if (!data) return null;
  return formatTrack(data);
}

// ---------------------------------------------------------------
// getAlbum (SoundCloud playlists / sets)
// ---------------------------------------------------------------

function getAlbum(playlistId) {
  var data = scGet("/playlists/" + playlistId);
  if (!data) return null;

  var tracks = (data.tracks || []).map(formatTrack);
  var artist = data.user ? data.user.username : "Unknown";
  var thumbnail = data.artwork_url
    ? data.artwork_url.replace("-large", "-t500x500")
    : "";

  return {
    id: String(data.id),
    name: data.title,
    artists: artist,
    cover_url: thumbnail,
    release_date: data.created_at ? data.created_at.substring(0, 10) : "",
    total_tracks: tracks.length,
    album_type: data.is_album ? "album" : "playlist",
    tracks: tracks,
    provider_id: "soundcloud-provider"
  };
}

// ---------------------------------------------------------------
// getArtist (SoundCloud user)
// ---------------------------------------------------------------

function getArtist(artistId) {
  var info = scGet("/users/" + artistId);
  if (!info) return null;

  var playlistData = scGet("/users/" + artistId + "/playlists?limit=20");
  var albums = [];

  if (playlistData && playlistData.collection) {
    for (var i = 0; i < playlistData.collection.length; i++) {
      var p = playlistData.collection[i];
      var thumbnail = p.artwork_url
        ? p.artwork_url.replace("-large", "-t500x500")
        : "";
      albums.push({
        id: String(p.id),
        name: p.title,
        artists: info.username,
        cover_url: thumbnail,
        release_date: p.created_at ? p.created_at.substring(0, 10) : "",
        total_tracks: p.track_count || 0,
        album_type: p.is_album ? "album" : "playlist",
        provider_id: "soundcloud-provider"
      });
    }
  }

  var avatar = info.avatar_url
    ? info.avatar_url.replace("-large", "-t500x500")
    : "";

  return {
    id: String(info.id),
    name: info.username,
    image_url: avatar,
    albums: albums,
    provider_id: "soundcloud-provider"
  };
}

// ---------------------------------------------------------------
// handleURL — resolve soundcloud.com / snd.sc links
// ---------------------------------------------------------------

function handleURL(url) {
  log.info("[soundcloud] handleURL:", url);

  var data = scResolve(url);
  if (!data) {
    return { success: false, error: "Could not resolve URL: " + url };
  }

  var kind = data.kind;

  // Single track
  if (kind === "track") {
    return {
      success: true,
      type: "track",
      track: formatTrack(data)
    };
  }

  // Playlist or album
  if (kind === "playlist") {
    var tracks = (data.tracks || []).map(formatTrack);
    var artist = data.user ? data.user.username : "Unknown";
    var thumbnail = data.artwork_url
      ? data.artwork_url.replace("-large", "-t500x500")
      : "";

    return {
      success: true,
      type: "album",
      album: {
        id: String(data.id),
        name: data.title,
        artists: artist,
        release_date: data.created_at ? data.created_at.substring(0, 10) : "",
        total_tracks: tracks.length,
        images: thumbnail,
        album_type: data.is_album ? "album" : "playlist",
        tracks: tracks
      }
    };
  }

  // User / artist
  if (kind === "user") {
    var artistData = getArtist(data.id);
    if (!artistData) {
      return { success: false, error: "Could not fetch artist data" };
    }
    return {
      success: true,
      type: "artist",
      artist: {
        id: artistData.id,
        name: artistData.name,
        image_url: artistData.image_url,
        albums: artistData.albums
      }
    };
  }

  return {
    success: false,
    error: "Unsupported SoundCloud content type: " + kind
  };
}

// ---------------------------------------------------------------
// checkAvailability
// ---------------------------------------------------------------

function checkAvailability(isrc, trackName, artistName) {
  if (!clientId) {
    return { available: false, error: "client_id not configured" };
  }

  // Search by name — SoundCloud doesn't index by ISRC publicly
  var limit = 5;
  var query = trackName + " " + artistName;
  var data = scGet("/search/tracks?q=" + encodeURIComponent(query) + "&limit=" + limit);

  if (!data || !data.collection || data.collection.length === 0) {
    return { available: false };
  }

  // Pick first streamable result
  for (var i = 0; i < data.collection.length; i++) {
    var t = data.collection[i];
    if (t.streamable !== false) {
      return {
        available: true,
        track_id: String(t.id),
        quality: settings.preferHLS !== false ? "HLS_AAC" : "MP3_128"
      };
    }
  }

  return { available: false };
}

// ---------------------------------------------------------------
// getDownloadUrl — resolve HLS or MP3 stream URL
// ---------------------------------------------------------------

function getDownloadUrl(trackId, quality) {
  var trackData = scGet("/tracks/" + trackId);
  if (!trackData) {
    return { success: false, error: "Track not found", error_type: "not_found" };
  }

  if (!trackData.streamable) {
    return { success: false, error: "Track is not streamable", error_type: "geo_blocked" };
  }

  var media = trackData.media;
  var preferHLS = quality === "HLS_AAC" || (quality !== "MP3_128" && settings.preferHLS !== false);

  // Try HLS AAC transcoding first
  if (preferHLS && media && media.transcodings) {
    for (var i = 0; i < media.transcodings.length; i++) {
      var tc = media.transcodings[i];
      if (tc.format && tc.format.protocol === "hls" && tc.format.mime_type === "audio/mpeg") {
        try {
          var hlsResp = fetch(withClientId(tc.url), { method: "GET" });
          if (hlsResp && hlsResp.ok) {
            var hlsData = hlsResp.json();
            if (hlsData && hlsData.url) {
              return {
                success: true,
                url: hlsData.url,
                format: "mp3",      // HLS AAC wrapped in MP3 container on SC
                quality: "HLS_AAC",
                is_hls: true
              };
            }
          }
        } catch (e) {
          log.warn("[soundcloud] HLS resolve failed:", String(e));
        }
      }
    }

    // Try progressive MP3 fallback
    for (var j = 0; j < media.transcodings.length; j++) {
      var tc2 = media.transcodings[j];
      if (tc2.format && tc2.format.protocol === "progressive") {
        try {
          var mp3Resp = fetch(withClientId(tc2.url), { method: "GET" });
          if (mp3Resp && mp3Resp.ok) {
            var mp3Data = mp3Resp.json();
            if (mp3Data && mp3Data.url) {
              return {
                success: true,
                url: mp3Data.url,
                format: "mp3",
                quality: "MP3_128",
                is_hls: false
              };
            }
          }
        } catch (e) {
          log.warn("[soundcloud] MP3 resolve failed:", String(e));
        }
      }
    }
  }

  return {
    success: false,
    error: "No streamable format found for track " + trackId,
    error_type: "stream_error"
  };
}

// ---------------------------------------------------------------
// download
// ---------------------------------------------------------------

function download(request, progressCallback) {
  log.info("[soundcloud] downloading:", request.track_name || request.isrc);

  var trackId = null;

  // If called from checkAvailability flow, track_id is in request
  if (request.track_id) {
    trackId = request.track_id;
  } else {
    // Fallback: search
    var avail = checkAvailability(request.isrc, request.track_name, request.artist_name);
    if (!avail.available) {
      return { success: false, error: "Track not found on SoundCloud", error_type: "not_found" };
    }
    trackId = avail.track_id;
  }

  var quality = request.quality || (settings.preferHLS !== false ? "HLS_AAC" : "MP3_128");
  var dlInfo = getDownloadUrl(trackId, quality);

  if (!dlInfo.success) {
    return { success: false, error: dlInfo.error, error_type: dlInfo.error_type || "stream_error" };
  }

  // Build output path
  var filename = gobackend.sanitizeFilename(
    (request.track_name || "track") + " - " + (request.artist_name || "soundcloud")
  ) + ".mp3";
  var outputPath = (request.output_dir || ".") + "/" + filename;

  log.info("[soundcloud] downloading to:", outputPath);

  var result = file.download(dlInfo.url, outputPath, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    },
    onProgress: function(received, total) {
      var pct = total > 0 ? received / total : 0;
      progressCallback(pct);
    }
  });

  if (!result.success) {
    return { success: false, error: "Download failed: " + result.error, error_type: "download_error" };
  }

  return {
    success: true,
    file_path: outputPath,
    format: "mp3",
    actual_bit_depth: 16,
    actual_sample_rate: 44100
  };
}

// ---------------------------------------------------------------
// Register
// ---------------------------------------------------------------

registerExtension({
  initialize: initialize,
  cleanup: cleanup,

  // Metadata provider
  searchTracks: searchTracks,
  customSearch: customSearch,
  getTrack: getTrack,
  getAlbum: getAlbum,
  getArtist: getArtist,

  // URL handler
  handleURL: handleURL,

  // Download provider
  checkAvailability: checkAvailability,
  getDownloadUrl: getDownloadUrl,
  download: download
});

log.info("[soundcloud] loaded");
