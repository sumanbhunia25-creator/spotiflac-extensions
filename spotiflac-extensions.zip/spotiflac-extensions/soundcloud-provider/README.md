# SoundCloud Provider

**Type:** Metadata Provider + Download Provider  
**API:** SoundCloud API v2 (requires a `client_id`)

## What it does

- **Search SoundCloud** — tracks appear in a dedicated search tab
- **Browse playlists & albums** — tap a set to see all tracks
- **Artist pages** — see all public playlists from any user
- **URL handler** — paste any `soundcloud.com` or `snd.sc` link to import a track, playlist, or artist
- **Download** — HLS AAC stream (best quality) or progressive MP3

## Getting your SoundCloud client_id

SoundCloud doesn't offer a public API program anymore, but you can extract the `client_id` from the web app's network requests:

1. Open [soundcloud.com](https://soundcloud.com) in a browser
2. Open **DevTools → Network** and filter by `client_id=`
3. Play any track — look for requests to `api-v2.soundcloud.com`
4. Copy the value of the `client_id` query parameter

Paste it into the extension's **Client ID** setting in SpotiFLAC → Settings → Extensions.

> **Note:** The client_id may rotate occasionally. If downloads stop working, repeat the steps above.

## Quality options

| Quality | Description |
|---|---|
| `HLS_AAC` | HLS stream — best quality available on SoundCloud (usually 128kbps AAC) |
| `MP3_128` | Progressive MP3 — direct file download |

## Settings

| Setting | Default | Description |
|---|---|---|
| SoundCloud Client ID | *(required)* | Extracted from soundcloud.com network requests |
| Search Results Limit | `20` | 1–50 per search |
| Prefer HLS AAC Stream | `true` | Use HLS over direct MP3 when available |

## Build & install

```bash
npm install
npm run build
npm run package   # → dist/soundcloud-provider.spotiflac-ext
```

## URL handler examples

Paste any of these into SpotiFLAC and the extension will handle them:

```
https://soundcloud.com/artist-name/track-name
https://soundcloud.com/artist-name/sets/playlist-name
https://soundcloud.com/artist-name
https://snd.sc/XXXXXX
```

## License

MIT
